package cn.demo2.domain;

/**
 * 进货商类
 * @author psl
 */
public class Supplier {
}
