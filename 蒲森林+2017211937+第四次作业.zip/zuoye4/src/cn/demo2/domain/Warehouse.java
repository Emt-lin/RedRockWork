package cn.demo2.domain;

/**
 * 仓库类
 * @author psl
 */
public class Warehouse {
}
