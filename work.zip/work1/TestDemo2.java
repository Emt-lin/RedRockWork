package work1;

public class TestDemo2 {
    public static void main(String[] args) {
        Cat cat = new Cat("加菲猫",3,20);
        Dog dog = new Dog("中华田园犬",2,30);
        Tiger tiger = new Tiger("东北虎",7,40);
        System.out.println(cat);
        cat.shape();
        cat.character();
        System.out.println(dog);
        dog.shape();
        dog.character();
        System.out.println(tiger);
        tiger.shape();
        tiger.character();
    }
}
